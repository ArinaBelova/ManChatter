<?php
// Set mysql connection parameters
$database_host = "dbhost.cs.man.ac.uk";
$database_user = "p40948vg";
$database_pass = "vladutz99";
$group_dbnames = array("2018_comp10120_m1","p40948vg");

// Establish connection with database
//$mysqli = new mysqli($database_host, $database_user, $database_pass, $group_dbnames[0]);

// Output connection error if something goes wrong
//if($mysqli -> connect_error)
//	die('Connect Error ('.$mysqli -> connect_errno.') '.$mysqli -> connect_error);
?>
